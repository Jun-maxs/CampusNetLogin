@echo off
chcp 65001 >nul 2>&1
title 校园网 Agent 一键安装
color 0A

echo ============================================
echo    校园网 Agent 一键安装程序
echo    控制面板: https://yuanai.best/gyk
echo ============================================
echo.

:: 检查是否以管理员运行
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [提示] 正在请求管理员权限...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set INSTALL_DIR=%USERPROFILE%\CampusNetAgent
set PYTHON_DIR=%INSTALL_DIR%\python
set PYTHON_EXE=%PYTHON_DIR%\python.exe
set AGENT_SCRIPT=%INSTALL_DIR%\agent.py
set PYTHON_URL=https://www.python.org/ftp/python/3.12.3/python-3.12.3-embed-amd64.zip

echo [1/4] 创建安装目录: %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: 复制 agent.py
echo [2/4] 复制 Agent 脚本...
copy /Y "%~dp0agent.py" "%AGENT_SCRIPT%" >nul

:: 检查是否已有 Python
if exist "%PYTHON_EXE%" (
    echo [3/4] 已检测到便携版 Python，跳过下载
    goto :setup_task
)

:: 检查系统是否已安装 Python
where python >nul 2>&1
if %errorlevel% equ 0 (
    echo [3/4] 系统已安装 Python，检查版本...
    python --version 2>&1 | findstr /R "3\.[0-9]" >nul
    if %errorlevel% equ 0 (
        echo       系统 Python 可用，跳过下载
        set PYTHON_EXE=python
        goto :setup_task
    )
)

:: 下载便携版 Python
echo [3/4] 下载便携版 Python (约 11MB)...
echo       下载地址: %PYTHON_URL%
powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference = 'SilentlyContinue'; try { Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%INSTALL_DIR%\python.zip' -UseBasicParsing } catch { Write-Host '下载失败:' $_.Exception.Message; exit 1 } }"
if %errorlevel% neq 0 (
    echo.
    echo [错误] Python 下载失败！请检查网络连接。
    echo        你也可以手动安装 Python: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo       解压中...
powershell -Command "Expand-Archive -Path '%INSTALL_DIR%\python.zip' -DestinationPath '%PYTHON_DIR%' -Force"
del "%INSTALL_DIR%\python.zip" >nul 2>&1
echo       Python 安装完成！

:setup_task
echo [4/4] 创建开机自启任务...

:: 创建启动脚本
(
echo @echo off
echo cd /d "%INSTALL_DIR%"
echo start /min "" "%PYTHON_EXE%" "%AGENT_SCRIPT%"
) > "%INSTALL_DIR%\启动Agent.bat"

:: 创建开机自启计划任务
schtasks /create /tn "CampusNetAgent" /tr "\"%INSTALL_DIR%\启动Agent.bat\"" /sc onlogon /rl highest /f >nul 2>&1
if %errorlevel% equ 0 (
    echo       开机自启已设置！
) else (
    echo       [提示] 自启设置失败，可手动运行"启动Agent.bat"
)

:: 创建桌面快捷方式
powershell -Command "& { $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), '校园网Agent.lnk')); $s.TargetPath = '%INSTALL_DIR%\启动Agent.bat'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.Description = '校园网自动登录 Agent'; $s.Save() }" >nul 2>&1

echo.
echo ============================================
echo    安装完成！
echo ============================================
echo.
echo    安装位置: %INSTALL_DIR%
echo    控制面板: https://yuanai.best/gyk
echo.
echo    - 桌面已创建快捷方式"校园网Agent"
echo    - 开机将自动启动
echo    - 现在启动 Agent? 
echo.

set /p START_NOW="输入 Y 立即启动 (Y/N): "
if /i "%START_NOW%"=="Y" (
    echo.
    echo 正在启动 Agent...
    cd /d "%INSTALL_DIR%"
    start "" "%PYTHON_EXE%" "%AGENT_SCRIPT%"
    echo Agent 已在后台运行！
)

echo.
echo 按任意键退出...
pause >nul
