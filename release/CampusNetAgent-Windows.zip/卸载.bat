@echo off
chcp 65001 >nul 2>&1
title 校园网 Agent 卸载
color 0C

echo ============================================
echo    校园网 Agent 卸载程序
echo ============================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set INSTALL_DIR=%USERPROFILE%\CampusNetAgent

echo [1/3] 停止 Agent 进程...
taskkill /f /im python.exe /fi "WINDOWTITLE eq *agent*" >nul 2>&1
taskkill /f /im pythonw.exe /fi "WINDOWTITLE eq *agent*" >nul 2>&1

echo [2/3] 删除开机自启任务...
schtasks /delete /tn "CampusNetAgent" /f >nul 2>&1

echo [3/3] 删除文件...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"

:: 删除桌面快捷方式
del "%USERPROFILE%\Desktop\校园网Agent.lnk" >nul 2>&1

echo.
echo 卸载完成！
echo.
pause
